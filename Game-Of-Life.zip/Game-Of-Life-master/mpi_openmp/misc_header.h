#ifndef MISC_HEADER_H
#define MISC_HEADER_H

/*Global vars visible in every source file*/
extern char** local_matrix;
extern int local_N;
extern int local_M;
extern int thread_count;

#endif